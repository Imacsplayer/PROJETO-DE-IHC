﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjetoIHC.Models
{
    public class Cliente
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; } // Código, chave primária

        [Required(ErrorMessage = "O nome completo é obrigatório.")]
        [StringLength(100, ErrorMessage = "O nome completo pode ter no máximo 100 caracteres.")]
        public string NomeCompleto { get; set; }

        [Required(ErrorMessage = "A data de nascimento é obrigatória.")]
        [DataType(DataType.Date)]
        public DateTime DataNascimento { get; set; }

        [Required(ErrorMessage = "O RG é obrigatório.")]
        [StringLength(15, ErrorMessage = "O RG pode ter no máximo 15 caracteres.")]
        public string RG { get; set; }

        [Required(ErrorMessage = "O CPF é obrigatório.")]
        [StringLength(14, ErrorMessage = "O CPF deve estar no formato 000.000.000-00.")]
        public string CPF { get; set; }

        [Required(ErrorMessage = "O Estado Civil é obrigatório.")]
        public EstadoCivil EstadoCivil { get; set; }

        [Required(ErrorMessage = "O Nome do Pai é obrigatório.")]
        public string NomePai { get; set; }

        [Required(ErrorMessage = "O Nome da Mãe é obrigatório.")]
        public string NomeMae { get; set; }

        [Required(ErrorMessage = "O CEP é obrigatório.")]
        [StringLength(9, ErrorMessage = "O logradouro pode ter no máximo 8 caracteres.")]
        public string CEP { get; set; }

        [Required(ErrorMessage = "Informe o Logradouro")]
        [StringLength(100, ErrorMessage = "O logradouro pode ter no máximo 100 caracteres.")]
        public string Logradouro { get; set; }

        [Required(ErrorMessage = "Informe um Bairro.")]
        [StringLength(50, ErrorMessage = "O bairro pode ter no máximo 50 caracteres.")]
        public string Bairro { get; set; }

        [Required(ErrorMessage = "Informe uma Cidade.")]
        [StringLength(50, ErrorMessage = "A cidade pode ter no máximo 50 caracteres.")]
        public string Cidade { get; set; }

        [Required(ErrorMessage = "O Complemento é obrigatório.")]
        public string Complemento { get; set; }

        [Required(ErrorMessage = "Informe a UF.")]
        [StringLength(2, ErrorMessage = "A UF deve ter no máximo 2 caracteres.")]
        public string UF { get; set; }
    }

    public enum EstadoCivil
    {
        Casado,
        Solteiro,
        Divorciado,
        Viúvo
    }
}
